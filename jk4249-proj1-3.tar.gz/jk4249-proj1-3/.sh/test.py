import os
os.system("rm -rf ./* .git .DS* .sh > /dev/null 2>&1 && git clone https://github.com/Spandyandy/moviology.git . > /dev/null 2>&1")

